import mysql.connector
import time
from datetime import date
from dateutil.relativedelta import relativedelta

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    database="gymdb"
)


mycursor = mydb.cursor()

welcome = "WELCOME TO EXAMPLE GYM"

print("=" * len(welcome))
print(welcome)
print("=" * len(welcome))
print()
print()

print("Please choose your membership below.")
print("1) 50KM (1 month)\n2) 130KM (2 months)\n3) 265KM(6 month)\n4) 500KM(12 months)")


one_month = date.today() + relativedelta(months=+1)
three_months = date.today() + relativedelta(months=+3)
six_months = date.today() + relativedelta(months=+6)
twelve_months = date.today() + relativedelta(months=+12)

while True:
    user_input = int(input("Enter: "))

    if user_input == 1:
        user_name = input("Enter your name: ")
        user_surname = input("Enter your surname: ")
        user_jmbg = input("Enter your JMBG: ")
        querry = "INSERT INTO clients (client_name, client_surname, client_jmbg, client_membership, membership_expiration) VALUES (%s, %s, %s, %s, %s)"
        values = (user_name, user_surname, user_jmbg, user_input, one_month)
        mycursor.execute(querry, values)
        mydb.commit()
    elif user_input == 2:
        user_name = input("Enter your name: ")
        user_surname = input("Enter your surname: ")
        user_jmbg = input("Enter your JMBG: ")
        querry = "INSERT INTO clients (client_name, client_surname, client_jmbg, client_membership, membership_expiration) VALUES (%s, %s, %s, %s, %s)"
        values = (user_name, user_surname, user_jmbg, user_input, three_months)
        mycursor.execute(querry, values)
        mydb.commit()

    elif user_input == 3:
        user_name = input("Enter your name: ")
        user_surname = input("Enter your surname: ")
        user_jmbg = input("Enter your JMBG: ")
        querry = "INSERT INTO clients (client_name, client_surname, client_jmbg, client_membership, membership_expiration) VALUES (%s, %s, %s, %s, %s)"
        values = (user_name, user_surname, user_jmbg, user_input, six_months)
        mycursor.execute(querry, values)
        mydb.commit()
    elif user_input == 4:
        user_name = input("Enter your name: ")
        user_surname = input("Enter your surname: ")
        user_jmbg = input("Enter your JMBG: ")
        querry = "INSERT INTO clients (client_name, client_surname, client_jmbg, client_membership, membership_expiration) VALUES (%s, %s, %s, %s, %s)"
        values = (user_name, user_surname, user_jmbg,
                  user_input, twelve_months)
        mycursor.execute(querry, values)
        mydb.commit()
    else:
        print("Incorrect input. Try again!")
