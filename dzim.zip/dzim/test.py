from datetime import date
from dateutil.relativedelta import relativedelta

one_month = date.today() + relativedelta(months=+1)
three_months = date.today() + relativedelta(months=+3)
six_months = date.today() + relativedelta(months=+6)
twelve_months = date.today() + relativedelta(months=+12)

print(one_month)
print(six_months)
