import string
import random


def card_number(length):
    temp = string.ascii_letters + string.digits
    card_number = ''.join(random.choice(temp) for i in range(8))
    print(card_number)


card_number(12)
